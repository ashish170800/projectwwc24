var Claims = artifacts.require("Claims");

module.exports = function(deployer) {
	deployer.deploy(Claims);
};